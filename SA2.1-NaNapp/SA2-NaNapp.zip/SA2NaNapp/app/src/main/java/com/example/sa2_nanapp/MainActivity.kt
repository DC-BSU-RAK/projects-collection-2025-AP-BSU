package com.example.sa2_nanapp

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var regionSpinner: Spinner
    private lateinit var countrySpinner: Spinner
    private lateinit var outputButton: Button
    private lateinit var resetButton: Button
    private lateinit var countryImage: ImageView

    private val regions = arrayOf("Select Region", "North America", "Asia", "Europe", "Africa", "South America")

    private val countriesMap = mapOf(
        "North America" to arrayOf("Select Country", "United States", "Canada", "Mexico"),
        "Asia" to arrayOf("Select Country", "Japan", "India", "Afghanistan", "Iran", "Korea", "Pakistan", "UAE", "Vietnam"),
        "Europe" to arrayOf("Select Country", "Germany", "Netherlands", "Poland", "Italy", "Romania", "Russia", "Switzerland", "Ukraine", "United Kingdom"),
        "Africa" to arrayOf("Select Country", "Egypt", "Nigeria", "Chad", "Somalia", "Zimbabwe"),
        "South America" to arrayOf("Select Country", "Argentina", "Brazil", "Chile", "Colombia", "Peru")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainLayout)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        regionSpinner = findViewById(R.id.regionSpinner)
        countrySpinner = findViewById(R.id.countrySpinner)
        outputButton = findViewById(R.id.outputButton)
        resetButton = findViewById(R.id.resetButton)
        countryImage = findViewById(R.id.countryImage)
        //Spinner Color
        val regionAdapter = ArrayAdapter(this, R.layout.spinner_item_color, regions)
        regionSpinner.adapter = regionAdapter

        regionSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    countrySpinner.isEnabled = false
                    outputButton.isEnabled = false
                    resetButton.visibility = View.GONE
                } else {
                    countrySpinner.isEnabled = true
                    resetButton.visibility = View.VISIBLE

                    val selectedRegion = regions[position]
                    val countries = countriesMap[selectedRegion] ?: arrayOf("Select Country")
                    val countryAdapter = ArrayAdapter(this@MainActivity, R.layout.spinner_item_color, countries)
                    countrySpinner.adapter = countryAdapter
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        countrySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                outputButton.isEnabled = position != 0
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        outputButton.setOnClickListener {
            val selectedCountry = countrySpinner.selectedItem.toString()
            when (selectedCountry) {
                // North America
                "United States" -> countryImage.setImageResource(R.drawable.united_states)
                "Canada" -> countryImage.setImageResource(R.drawable.canada)
                "Mexico" -> countryImage.setImageResource(R.drawable.mexico)

                // South America
                "Argentina" -> countryImage.setImageResource(R.drawable.argentina)
                "Brazil" -> countryImage.setImageResource(R.drawable.brazil)
                "Chile" -> countryImage.setImageResource(R.drawable.chile)
                "Colombia" -> countryImage.setImageResource(R.drawable.colombia)
                "Peru" -> countryImage.setImageResource(R.drawable.peru)

                // Asia
                "Afghanistan" -> countryImage.setImageResource(R.drawable.afghanistan)
                "Japan" -> countryImage.setImageResource(R.drawable.japan)
                "India" -> countryImage.setImageResource(R.drawable.india)
                "Iran" -> countryImage.setImageResource(R.drawable.iran)
                "Korea" -> countryImage.setImageResource(R.drawable.korea)
                "Pakistan" -> countryImage.setImageResource(R.drawable.pakistan)
                "UAE" -> countryImage.setImageResource(R.drawable.uae)
                "Vietnam" -> countryImage.setImageResource(R.drawable.vietnam)

                // Europe
                "Germany" -> countryImage.setImageResource(R.drawable.germany)
                "Netherlands" -> countryImage.setImageResource(R.drawable.netherlands)
                "Poland" -> countryImage.setImageResource(R.drawable.poland)
                "Italy" -> countryImage.setImageResource(R.drawable.italy)
                "Romania" -> countryImage.setImageResource(R.drawable.romania)
                "Russia" -> countryImage.setImageResource(R.drawable.russia)
                "Switzerland" -> countryImage.setImageResource(R.drawable.switzerland)
                "Ukraine" -> countryImage.setImageResource(R.drawable.ukraine)
                "United Kingdom" -> countryImage.setImageResource(R.drawable.uk)

                // Africa
                "Chad" -> countryImage.setImageResource(R.drawable.chad)
                "Egypt" -> countryImage.setImageResource(R.drawable.egypt)
                "Nigeria" -> countryImage.setImageResource(R.drawable.nigeria)
                "Somalia" -> countryImage.setImageResource(R.drawable.somalia)
                "Zimbabwe" -> countryImage.setImageResource(R.drawable.zimbabwe)
            }
            countryImage.visibility = View.VISIBLE
        }

        resetButton.setOnClickListener {
            regionSpinner.setSelection(0)
            countrySpinner.isEnabled = false
            outputButton.isEnabled = false
            countryImage.visibility = View.GONE
            resetButton.visibility = View.GONE
        }
    }
}
