package com.example.sa22_multiview_coloring

import android.graphics.Color

object ColorStore {
    var shape1Color: Int = Color.RED
    var shape2Color: Int = Color.YELLOW
    var shape3Color: Int = Color.BLUE
    var shape4Color: Int = Color.GREEN

}
