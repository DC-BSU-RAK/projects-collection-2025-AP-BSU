package com.example.sa22_multiview_coloring

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.fragment.app.Fragment

class Page3Fragment : Fragment() {

    private lateinit var spinner: Spinner

    private val colorMap = mapOf(
        "Red" to Color.RED,
        "Green" to Color.GREEN,
        "Blue" to Color.BLUE,
        "Yellow" to Color.YELLOW
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_page3, container, false)

        spinner = view.findViewById(R.id.colorSpinner)

        val colorNames = colorMap.keys.toList()
        val colorValues = colorMap.values.toList()

        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            colorNames
        )
        spinner.adapter = adapter

        // 🔁 Restore previous color selection
        val currentColor = ColorStore.shape3Color
        val selectedIndex = colorValues.indexOf(currentColor)
        if (selectedIndex >= 0) {
            spinner.setSelection(selectedIndex)
            view.findViewById<View>(R.id.colorPreview)?.setBackgroundColor(currentColor)
        }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, selectedView: View?, position: Int, id: Long) {
                val selectedColor = colorValues[position]
                ColorStore.shape3Color = selectedColor
                view.findViewById<View>(R.id.colorPreview)?.setBackgroundColor(selectedColor)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        return view
    }
}
