package com.example.sa22_multiview_coloring

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // ✅ Use your actual XML file name (must match!)

        // Ensure R.id.main exists in your layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val pageSpinner = findViewById<Spinner>(R.id.pageSpinner)
        val pages = listOf("Page 1", "Page 2", "Page 3", "Page 4")

        pageSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            pages
        )

        // 🔄 Load the appropriate fragment when user selects a page
        pageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>, view: View?, position: Int, id: Long
            ) {
                val fragment = when (position) {
                    0 -> Page1Fragment()
                    1 -> Page2Fragment()
                    2 -> Page3Fragment()
                    3 -> Page4Fragment()
                    else -> Page1Fragment()
                }
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .commit()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }
}
