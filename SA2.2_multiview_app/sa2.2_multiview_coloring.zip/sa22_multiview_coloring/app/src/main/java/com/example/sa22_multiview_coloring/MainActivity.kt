package com.example.sa22_multiview_coloring

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loadSavedColors()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 🔁 Launch Tutorial.kt when clicked
        findViewById<Button>(R.id.tutorialButton).setOnClickListener {
            startActivity(Intent(this, Tutorial::class.java))
        }

        val pageSpinner = findViewById<Spinner>(R.id.pageSpinner)
        val pages = listOf("Page 1", "Page 2", "Page 3", "Page 4")

        pageSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            pages
        )

        pageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>, view: View?, position: Int, id: Long
            ) {
                val fragment = when (position) {
                    0 -> Page1Fragment()
                    1 -> Page2Fragment()
                    2 -> Page3Fragment()
                    3 -> Page4Fragment()
                    else -> Page1Fragment()
                }
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .commit()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun loadSavedColors() {
        val prefs = getSharedPreferences("ColorPrefs", Context.MODE_PRIVATE)
        ColorStore.shape1Color = prefs.getInt("shape1Color", ColorStore.shape1Color)
        ColorStore.shape2Color = prefs.getInt("shape2Color", ColorStore.shape2Color)
        ColorStore.shape3Color = prefs.getInt("shape3Color", ColorStore.shape3Color)
        ColorStore.shape4Color = prefs.getInt("shape4Color", ColorStore.shape4Color)
    }

    companion object {
        fun saveColor(context: Context, key: String, color: Int) {
            context.getSharedPreferences("ColorPrefs", Context.MODE_PRIVATE)
                .edit { putInt(key, color) }
        }
    }
}
